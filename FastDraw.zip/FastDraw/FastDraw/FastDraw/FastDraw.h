//
//  FastDraw.h
//  FastDraw
//
//  Created by 张睿杰 on 2021/2/11.
//

#import <Foundation/Foundation.h>

//! Project version number for FastDraw.
FOUNDATION_EXPORT double FastDrawVersionNumber;

//! Project version string for FastDraw.
FOUNDATION_EXPORT const unsigned char FastDrawVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FastDraw/PublicHeader.h>


