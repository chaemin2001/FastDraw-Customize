//
//  ViewController.swift
//  FastDrawDemo
//
//  Created by 张睿杰 on 2021/2/13.
//

import UIKit
import FastDraw
import Foundation

extension UIColor {
  @nonobjc class var gray: UIColor {
    return UIColor(red: 238/255.0, green: 238/255.0, blue: 238/255.0, alpha: 1)
  }
}

class ViewController: UIViewController, UIColorPickerViewControllerDelegate {
    
    var drawboardview: DrawBoardView!
    let picker = UIColorPickerViewController()
    let penButton = UIButton(frame: CGRect(x: 50, y: 50, width: 50, height: 50))
    let eraserButton = UIButton(frame: CGRect(x: 100, y: 50, width: 50, height: 50))
    let highlighterButton = UIButton(frame: CGRect(x: 150, y: 50, width: 50, height: 50))
    let lassoButton = UIButton(frame: CGRect(x: 200, y: 50, width: 50, height: 50))
    let exportButton = UIButton(frame: CGRect(x: 250, y: 50, width: 50, height: 50))
    
    var penTapNum = 0 {
        didSet {
            if (penTapNum == 0) {
                penButton.setImage(UIImage(systemName: "pencil.and.outline"), for: .normal)
            } else {
                penButton.setImage(UIImage(named: "custom.pencil.and.outline"), for: .normal)
            }
        }
    }
    
    var eraserTapNum = 0 {
        didSet {
            if (eraserTapNum == 0) {
                eraserButton.setImage(UIImage(systemName: "rectangle.lefthalf.fill"), for: .normal)
            } else {
                eraserButton.setImage(UIImage(named: "custom.rectangle.trailinghalf.filled"), for: .normal)
            }
        }
    }
    
    var highlighterTapNum = 0 {
        didSet {
            if (highlighterTapNum == 0) {
                highlighterButton.setImage(UIImage(systemName: "highlighter"), for: .normal)
            } else {
                highlighterButton.setImage(UIImage(named: "custom.highlighter"), for: .normal)
            }
        }
    }
    
    var lassoTapNum = 0 {
        didSet {
            if (lassoTapNum == 0) {
                lassoButton.setImage(UIImage(systemName: "circle.dashed"), for: .normal)
            } else {
                lassoButton.setImage(UIImage(named: "custom.circle.dashed"), for: .normal)
            }
        }
    }
    
    var exportTapNum = 0 {
        didSet {
            if (exportTapNum == 0) {
                exportButton.setImage(UIImage(systemName: "square.and.arrow.up"), for: .normal)
            } else {
                exportButton.setImage(UIImage(named: "custom.square.and.arrow.up"), for: .normal)
            }
        }
    }
    
    func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
        Brush.shared.color = viewController.selectedColor
        
    }
    
    func colorPickerViewControllerDidSelectColor(_ viewController: UIColorPickerViewController) {
        Brush.shared.color = viewController.selectedColor
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        view.tintColor = .systemGray2
        
        drawboardview = DrawBoardView(frame: CGRect(origin: CGPoint(x: 0, y: 100),
                                                    size: view.frame.size))
        drawboardview.setupDrawing()
        drawboardview.delegate = self
        drawboardview.backgroundColor = .gray
        self.view.addSubview(drawboardview)
        picker.delegate = self
        setButtons()
    }
    
    private func setButtons() {
        
        penButton.setImage(UIImage(systemName: "pencil.and.outline"), for: .normal)
        penButton.addTarget(self, action: #selector(penTapped), for: .touchUpInside)
        eraserButton.setImage(UIImage(systemName: "rectangle.lefthalf.fill"), for: .normal)
        eraserButton.addTarget(self, action: #selector(eraserTapped), for: .touchUpInside)
        highlighterButton.setImage(UIImage(systemName: "highlighter"), for: .normal)
        highlighterButton.addTarget(self, action: #selector(highlighterTapped), for: .touchUpInside)
        lassoButton.setImage(UIImage(systemName: "circle.dashed"), for: .normal)
        lassoButton.addTarget(self, action: #selector(lassoTapped), for: .touchUpInside)
        exportButton.setImage(UIImage(systemName: "square.and.arrow.up"), for: .normal)
        exportButton.addTarget(self, action: #selector(exportTapped), for: .touchUpInside)
        
        for button in [penButton, eraserButton, highlighterButton, lassoButton, exportButton] {
            self.view.addSubview(button)
        }
    }
    
    @objc func penTapped() {
        if (penTapNum == 0) {
            penTapNum += 1
            (eraserTapNum, highlighterTapNum, lassoTapNum, exportTapNum) = (0,0,0,0)
            Brush.shared.type = .pen
            Brush.shared.color = .black
            Brush.shared.width = 5
        } else if (penTapNum == 1) {
            penTapNum += 1
            self.present(picker, animated: true)
        } else {
            penTapNum = 0
        }
    }

    @objc func eraserTapped() {
        if (eraserTapNum == 0) {
            eraserTapNum += 1
            (penTapNum, highlighterTapNum, lassoTapNum, exportTapNum) = (0,0,0,0)
            Brush.shared.type = .eraser
            Brush.shared.width = 20
        } else if (eraserTapNum == 1) {
            eraserTapNum += 1
        } else {
            eraserTapNum = 0
        }
    }
    
    @objc func lassoTapped() {
        if (lassoTapNum == 0) {
            lassoTapNum += 1
            (eraserTapNum, highlighterTapNum, penTapNum, exportTapNum) = (0,0,0,0)
            Brush.shared.type = .lasso
        } else if (lassoTapNum == 1) {
            lassoTapNum += 1
        } else {
            lassoTapNum = 0
        }
    }
    
    @objc func highlighterTapped() {
        if (highlighterTapNum == 0) {
            highlighterTapNum += 1
            (eraserTapNum, penTapNum, lassoTapNum, exportTapNum) = (0,0,0,0)
            Brush.shared.type = .pen
            Brush.shared.color = .yellow
            Brush.shared.width = 20
        } else if (highlighterTapNum == 1) {
            highlighterTapNum += 1
            self.present(picker, animated: true)
        } else {
            highlighterTapNum = 0
        }
    }
    
    @objc func exportTapped() {
        if (exportTapNum == 0) {
            exportTapNum += 1
            (eraserTapNum, highlighterTapNum, lassoTapNum, penTapNum) = (0,0,0,0)
            let baseURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            let url = baseURL.appendingPathComponent("test.pdf")
            drawboardview.drawPDF(url: url)
            print(url)
        } else if (exportTapNum == 1) {
            exportTapNum += 1
        } else {
            exportTapNum = 0
        }
    }
}

extension ViewController: DrawBoardViewDelegate {
    func operationEnded(operation: FastOperation) {
        dump(operation)
    }
}
